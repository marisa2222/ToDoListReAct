import React, { useState } from "react";

const Tasks = ({ taskList }) => {
  
  
  //  if (task_edit_botton.innerText.toLowerCase() == "edit") {
  //     task_input.removeAttribute("readonly");
  //     task_input.focus();
  //     task_edit_botton.innerText = "Save";
  //     task_input.style.textDecoration = "none";
  //   } else {
  //     task_input.setAttribute("readonly", "readonly");
  //     task_edit_botton.innerText = "Edit";
  //     const task_edited = findTask(id);
  //     task_edited.value = task_input.value;
  //     setStorage();
  // }
  const editTodo = (item) => {
    if (item.target.innerHTML === "Edit") {
      const txt = item.target.parentElement.parentElement.firstChild.firstChild;
      txt.readOnly = false;
      txt.focus();
      txt.style.textDecoration = "none";
      item.target.innerHTML = "Save";
    } else {
      item.target.innerHTML = "Edit";
    }
  };
const deleteTodo = (item) => {
  if (window.confirm("Are you sure you want to delete this task?")) {
    taskList.splice(0, 1);
  }
  if (item.target.innerHTML === "Edit") {
    const txt = item.target.parentElement.parentElement.firstChild.firstChild;
    txt.readOnly = false;
    txt.focus();
    txt.style.textDecoration = "none";
    item.target.innerHTML = "Save";
  } else {
    item.target.innerHTML = "Edit";
  }
};
  return (
    <div className="task-list">
      <div id="tasks">
        {taskList.map((text) => {
          return (
            <div className="task">
              <div className="content">
                <input className="text" id="txt" value={text} readOnly="true" />
              </div>
              <div className="actions">
                <button onClick={editTodo} className="Edit">
                  Edit
                </button>
                <button onClick={deleteTodo} className="Delete">
                  Delete
                </button>
                {/* <button onClick={() => markedTodo(item)} className="Marked">
                  Marked */}
                {/* </button> */}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Tasks;

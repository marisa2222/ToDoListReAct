import React from "react";
// import { ReactDOM } from "react";
import Header from "./Components/Header";

let App = () =>{
 return (
  <div className="container">
    <Header />
  </div>
 )
};

export default App;